Subroutine gw_doc
! ~ ~ ~ PURPOSE ~ ~ ~
!!    this subroutine estimates DOC transport by baseflow to streamflow

!!    ~ ~ ~ INCOMING VARIABLES ~ ~ ~
!!    name        |units         |definition
!!    ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
!!    alpha_bf(:) |1/days        |alpha factor for groundwater recession curve
!!    alpha_bfe(:)|none          |Exp(-alpha_bf(:))
!!    deepst(:)   |mm H2O        |depth of water in deep aquifer
!!    ihru        |none          |HRU number
!!    gw_delaye(:)|none          |Exp(-1./(delay(:)) where delay(:) is the 
!!                               |groundwater delay (time required for water
!!                               |leaving the bottom of the root zone to reach
!!                               |the shallow aquifer; units-days)
!!    gw_revap(:) |none          |revap coeff: this variable controls the amount
!!                               |of water moving from the shallow aquifer to
!!                               |the root zone as a result of soil moisture
!!                               |depletion
!!    gw_spyld(:) |m**3/m**3     |specific yield for shallow aquifer
!!    gwht(:)     |m             |groundwater height
!!    gwqmn(:)    |mm H2O        |threshold depth of water in shallow aquifer
!!                               |required before groundwater flow will occur
!!    pet_day     |mm H2O        |potential evapotranspiration on current day
!!                               |in HRU
!!    rchrg(:)    |mm H2O        |amount of water entering shallow aquifer on
!!                               |previous day in HRU
!!    rchrg_dp(:) |none          |recharge to deep aquifer: the fraction of
!!                               |root zone percolation that reaches the deep
!!                               |aquifer
!!    revapmn(:)  |mm H2O        |threshold depth of water in shallow aquifer
!!                               |required to allow revap to occur
!!    sepbtm      |mm H2O        |percolation from bottom of soil profile for
!!                               |the day in HRU
!!    shallst(:)  |mm H2O        |depth of water in shallow aquifer
!!    ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~

!!    ~ ~ ~ OUTGOING VARIABLES ~ ~ ~
!!    name        |units         |definition
!!    ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
!!    deepst(:)   |mm H2O        |depth of water in deep aquifer
!!    gw_q(:)     |mm H2O        |groundwater contribution to streamflow from
!!                               |HRU on current day
!!    gwht(:)     |m             |groundwater height
!!    gwseep      |mm H2O        |amount of water recharging deep aquifer on
!!                               |current day in HRU
!!    rchrg(:)    |mm H2O        |amount of water recharging both aquifers on
!!                               |current day in HRU
!!    revapday    |mm H2O        |amount of water moving from the shallow 
!!                               |aquifer into the soil profile or being taken
!!                               |up by plant roots in the shallow aquifer
!!    shallst(:)  |mm H2O        |depth of water in shallow aquifer
!!    ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~

!!    ~ ~ ~ LOCAL DEFINITIONS ~ ~ ~
!!    name        |units         |definition
!!    ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
!!    j           |none          |HRU number
!!    rchrg1      |mm H2O        |amount of water entering shallow aquifer on
!!                               |previous day
!!    ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~

!!    ~ ~ ~ SUBROUTINES/FUNCTIONS CALLED ~ ~ ~
!!    Intrinsic: Max

!!    ~ ~ ~ ~ ~ ~ END SPECIFICATIONS ~ ~ ~ ~ ~ ~
!!    revap is subtracted and rchrg is delayed (johnson, 1977)
 use carbon_para
 use parm

 integer :: j
 real :: rchrg_doc1, revap_doc, gwseep_doc

 j = 0
 j = ihru

 rchrg_doc1 = 0.
 rchrgn_doc1 = cbn_hru(j)%rchrg_doc
 if (rchrg_doc1 < 1.e-6) rchrg_doc1 = 0.0

 !! compute DOC aquifer loading from recharge for current day
 cbn_hru(j)%rchrg_doc = 0.
 cbn_hru(j)%rchrg_doc = (1.- gw_delaye(j))*cbn_hru(j)%perco_DOC+gw_delaye(j)*rchrg_doc1 ! calculate the DOC recharge
 cbn_hru(j)%shallst_doc = cbn_hru(j)%shallst_doc + cbn_hru(j)%rchrg_doc !add DOC recharge into shallow aquifer DOC pool

 if (cbn_hru(j)%shallst_doc < 1.e-6) cbn_hru(j)%shallst_doc = 0.0
 if (shallst(j) < 1.e-6) shallst(j) = 0.0
 if (gw_q(j) < 1.e-6) gw_q(j) = 0.0
 if (revapday < 1.e-6) revapday = 0.0
 if (gwseep < 1.e-6) gwseep = 0.0

 !! compute DOC groundwater contribution to streamflow for day
 xx = shallst(j) + gw_q(j) + revapday + gwseep 
 if (xx > 1.) then
     xx = cbn_hru(j)%shallst_doc / (shallst(j) + gw_q(j) + revapday + gwseep) 
 else
     xx = 0.
 end if
 if (xx < 1.e-6) xx = 0.0
 cbn_hru(j)%trans%gwq_DOC =0.
 cbn_hru(j)%trans%gwq_DOC = xx * gw_q(j)  !DOC amount transported by groundwater

!no3gw(j) = no3gw(j) * bmp_sns(j) !! bmp adjustment
 revap_doc = xx * revapday
 gwseep_doc = xx * gwseep

 revap_doc = amax1(1.e-6,revap_doc)
 gwseep_doc = amax1(1.e-6,gwseep_doc)

 !! subtract DOC transport losses from the shallow aquifer
 cbn_hru(j)%shallst_doc = cbn_hru(j)%shallst_doc-cbn_hru(j)%trans%gwq_DOC-revap_doc-gwseep_doc
 cbn_hru(j)%shallst_doc = amax1 (0., cbn_hru(j)%shallst_doc)

 !! compute DOC reaction losses in the groundwater
 cbn_hru(j)%shallst_doc = cbn_hru(j)%shallst_doc*Exp(-.693 /cbn_sp(j)% hlife_docgw) ! DOC reaction, first-order decay
 cbn_hru(j)%shallst_doc = amax1(0., cbn_hru(j)%shallst_doc)
 
 return
 end subroutine
