      subroutine orgncswat2(iwave)

!!    ~ ~ ~ PURPOSE ~ ~ ~
!!    this subroutine calculates the amount of organic nitrogen removed in
!!    surface runoff - when using CSWAT==2 it 


!!    ~ ~ ~ INCOMING VARIABLES ~ ~ ~
!!    name          |units        |definition
!!    ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
!!    da_ha         |ha           |area of watershed in hectares
!!    enratio       |none         |enrichment ratio calculated for day in HRU
!!    erorgn(:)     |none         |organic N enrichment ratio, if left blank
!!                                |the model will calculate for every event
!!    ihru          |none         |HRU number
!!    iwave         |none         |flag to differentiate calculation of HRU and
!!                                |subbasin sediment calculation
!!                                |iwave = 0 for HRU
!!                                |iwave = subbasin # for subbasin
!!    sedyld(:)     |metric tons  |daily soil loss caused by water erosion in
!!                                |HRU
!!    sol_bd(:,:)   |Mg/m**3      |bulk density of the soil
!!    sol_z(:,:)    |mm           |depth to bottom of soil layer
!!    sub_bd(:)     |Mg/m^3       |bulk density in subbasin first soil layer
!!    sub_fr(:)     |none         |fraction of watershed area in subbasin
!!    sub_orgn(:)   |kg N/ha      |amount of nitrogen stored in all organic
!!    sedc_d(:)     |kg C/ha      |amount of C lost with sediment
!!
!!
!!     
!!                                |pools 
!!    ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~

!!    ~ ~ ~ OUTGOING VARIABLES ~ ~ ~
!!    name          |units        |definition
!!    ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
!!    sedorgn(:)    |kg N/ha      |amount of organic nitrogen in surface runoff
!!                                |in HRU for the day
!!    ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~

!!    ~ ~ ~ LOCAL DEFINITIONS ~ ~ ~
!!    name        |units         |definition
!!    ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
!!    conc        |              |concentration of organic N in soil
!!    er          |none          |enrichment ratio
!!    j           |none          |HRU number
!!    wt1         |none          |conversion factor (mg/kg => kg/ha)
!!    xx          |kg N/ha       |amount of organic N in first soil layer
!!    ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~

!!    ~ ~ ~ ~ ~ ~ END SPECIFICATIONS ~ ~ ~ ~ ~ ~
      use carbon_para
      use parm

      integer, intent (in) :: iwave
      integer :: j
      real :: xx, wt1, er, conc
      real :: sol_mass, QBC, VBC, YBC, YOC, YW, TOT, YEW, X1, PRMT_21, PRMT_44
      real :: DK,  V, X3, CO, CS, perc_clyr, latc_clyr
      real :: ABL,X2,XX1,DOC_mass,VBC1,sat_DIC,cw_DIC,sat_ly,DIC_ly   !added by Du, loacal variables for carbon module
      integer :: k
      latc_clyr = 0.
        
      j = 0
      j = ihru
      
      !!for debug purpose by zhang
      !if (iyr == 1991 .and. i==235) then
      ! write(*,*) 'stop'
      !end if

      xx = 0.
	  wt1 = 0.  !! conversion factor
      er = 0.	!! enrichment ratio
      if (iwave <= 0) then
        !! HRU calculations
        !xx = sol_n(1,j) + sol_fon(1,j) + sol_mn(1,j)
        xx = sol_LSN(1,j)+sol_LMN(1,j)+sol_HPN(1,j)+sol_HSN(1,j) !+sol_BMN(1,j)
        !wt = sol_bd(1,j) * sol_z(1,j) * 10. (tons/ha)
        !wt1 = wt/1000
        wt1 = sol_bd(1,j) * sol_z(1,j) / 100.

        if (erorgn(j) > .001) then
          er = erorgn(j)
        else
          er = enratio
        end if

      else
        !! subbasin calculations
        xx = sub_orgn(iwave)
        wt1 = sub_bd(iwave) * sol_z(1,j) / 100.        
       
        er = enratio
      end if

      conc = 0.
      conc = xx * er / wt1

      if (iwave <= 0) then
        !! HRU calculations
        sedorgn(j) = .001 * conc * sedyld(j) / hru_ha(j)
      else
        !! subbasin calculations
        sedorgn(j) = .001 * conc * sedyld(j) / (da_ha * sub_fr(iwave))
      end if

	!! update soil nitrogen pools only for HRU calculations
      if (iwave <= 0 .and. xx > 1.e-6) then
        xx1 = (1. - sedorgn(j) / xx)
        
        !!add by zhang to update soil nitrogen pools
        
		sol_LSN(1,j) = sol_LSN(1,j) * xx1
		sol_LMN(1,j) = sol_LMN(1,j) * xx1
		sol_HPN(1,j) = sol_HPN(1,j) * xx1
		sol_HSN(1,j) = sol_HSN(1,j) * xx1
		!sol_BMN(1,j) = sol_BMN(1,j) * xx1
      end if
      
      !return
      
      !Calculate runoff and leached C&N from micro-biomass
      latc_clyr = 0.
      sol_mass = 0.  
      !kg/ha
      sol_mass = (sol_z(1,j) / 1000.) * 10000. * sol_bd(1,j)* 1000. * (1- sol_rock(1,j) / 100.)
      
      
      QBC=0.    !c loss with runoff or lateral flow
      VBC=0.    !c los with vertical flow
      YBC=0.    !BMC LOSS WITH SEDIMENT
      YOC=0.    !Organic C loss with sediment
      YW=0.     !YW = WIND EROSION (T/HA)
      TOT=sol_HPC(1,j)+sol_HSC(1,j)+sol_LMC(1,j)+sol_LSC(1,j) !Total organic carbon in layer 1
      !YEW = MIN(er*(sedyld(j)/hru_ha(j)+YW/hru_ha(j))/(sol_mass/1000.),.9)
      ! Not sure whether should consider enrichment ratio or not!
      YEW = MIN(cbn_sp(j)%enr_POC*(sedyld(j)/hru_ha(j)+YW/hru_ha(j))/(sol_mass/1000.),.9) !fraction of soil erosion of total soil mass
      X1=1.-YEW
	  !YEW=MIN(ER*(YSD(NDRV)+YW)/WT(LD1),.9)
	  !ER enrichment ratio
	  !YSD water erosion
	  !YW wind erosion
      YOC=YEW*TOT
      sol_HSC(1,j)=sol_HSC(1,j)*X1
      sol_HPC(1,j)=sol_HPC(1,j)*X1
      sol_LS(1,j)=sol_LS(1,j)*X1
      sol_LM(1,j)=sol_LM(1,j)*X1
      sol_LSL(1,j)=sol_LSL(1,j)*X1
      sol_LSC(1,j)=sol_LSC(1,j)*X1
      sol_LMC(1,j)=sol_LMC(1,j)*X1
      sol_LSLC(1,j)=sol_LSLC(1,j)*X1
      sol_LSLNC(1,j)=sol_LSC(1,j)-sol_LSLC(1,j)
  !-----------------added by Du,calculated RPOC and LPOC by soil erosion from top soil later-------------!
      cbn_hru(j)%cbn_ly%percly_DOC=0.
      cbn_hru(j)%cbn_ly%percly_DIC=0.
      cbn_hru(j)%cbn_ly%latly_DOC=0.
      cbn_hru(j)%cbn_ly%latly_DIC=0.
      !
      cbn_hru(j)%trans%RPOC=(sol_HSC(1,j)+sol_HPC(1,j))*YEW  !added by Du,calculated RPOC transport  
      cbn_hru(j)%trans%LPOC=(sol_LMC(1,j)+sol_LSC(1,j))*YEW  !added by Du,calculated LPOC transport
  !-----------------added by Du,calculated RPOC and LPOC by soil erosion from top soil later-------------!
      if (surfq(j) > 0) then
        !write(*,*) 'stop'
      end if
!--------------added by Du, DIC processes in top soil ayer------------------------------------------------------------------------------------------------!
      cbn_hru(j)%cbn_ly(1)%DIC=cbn_hru(j)%cbn_ly(1)%DIC+sol_RSPC(1,j)  !add mineralization from organic carbon to DIC pool (kg/ha)
      X2=sol_st(1,j)+sol_wpmm(1,j) ! added by DU,SW-soil water content (mm) simuated by SWAT
      sat_DIC=0.1*X2*cbn_sp(j)%DIC_sat ! DIC saturation (kg/ha)
      if (cbn_hru(j)%cbn_ly(1)%DIC > sat_DIC ) cbn_hru(j)%cbn_ly(1)%DIC=cbn_hru(j)%cbn_ly(1)%DIC-(cbn_hru(j)%cbn_ly(1)%DIC-sat_DIC)*cbn_sp(j)%k_eva
      V = surfq(j) + sol_prk(1,j) + flat(1,j)
      if (cbn_hru(j)%cbn_ly(1)%DIC > .0 .and. V>1.E-10) then
          sat_ly=sol_por(1,j)*sol_z(1,j)   ! saturate water content of the soil layer (mm)
          cw_DIC=max(cbn_hru(j)%cbn_ly(1)%DIC*(1-exp(-V/sat_ly))/V,.0)    ! DIC concentration in mobile water (kg/ha/mm)
          cbn_hru(j)%trans%surfq_DIC=cbn_sp(j)%peroc_DIC*cw_DIC*surfq(j) !loss by surface runoff
          cbn_hru(j)%trans%latq_DIC=cbn_sp(j)%peroc_DIC*cw_DIC*flat(1,j) !loss by lateral flow
          cbn_hru(j)%cbn_ly(1)%percly_DIC=cw_DIC*sol_prk(1,j)  !loss by percolation into underlying soil layer
          ! update DIC mass blance afer transport loss 
          cbn_hru(j)%cbn_ly(1)%DIC=cbn_hru(j)%cbn_ly(1)%DIC-cw_DIC*(sol_prk(1,j)+cbn_sp(j)%peroc_DIC*(surfq(j)+flat(1,j))) 
          if (cbn_hru(j)%cbn_ly(1)%DIC <0.) cbn_hru(j)%cbn_ly(1)%DIC=0.
      endif
!--------------added by Du, DIC processes in top soil ayer------------------------------------------------------------------------------------------------!
      IF(sol_BMC(1,j)>.00) THEN  !modified by Du (0.01 to 0.00)
          !PRMT_21 = 0.  !KOC FOR CARBON LOSS IN WATER AND SEDIMENT(500._1500.) KD = KOC * C
          !PRMT_21 = 1000.
          sol_WOC(1,j) = sol_LSC(1,j)+sol_LMC(1,j)+sol_HPC(1,j)+sol_HSC(1,j)+sol_BMC(1,j) 
          DK=.0001*cbn_sp(j)%kd_OC*sol_WOC(1,j)
          !X1=PO(LD1)-S15(LD1)
          X1 = sol_por(1,j)*sol_z(1,j)-sol_wpmm(1,j) !mm
          IF (X1 <= 0.) THEN
            X1 = 0.01
          END IF
          XX=X1+DK
    !-------------------------------------------------------------------------------------------------------
          XX1=X2+DK
          ABL=1.-EXP(XX1)   !added by Du, carbon allocation coefficient ABL from biomass to leaching DOC
          DOC_mass=0.
          DOC_mass=ABL*sol_BMC(1,j) ! DOC mass in top layer (kg/ha) 
    !-------------------------------------------------------------------------------------------------------
          !V=QD+Y4
          V = surfq(j) + sol_prk(1,j) + flat(1,j)
	      !QD surface runoff
          X3=0.
          IF(V>1.E-10)THEN
              X3=sol_BMC(1,j)*(1.-EXP(-V/XX)) !loss of biomass C
              !PRMT_44 = 0. !RATIO OF SOLUBLE C CONCENTRATION IN RUNOFF TO PERCOLATE(0.1_1.)
              !PRMT_44 = .5
              CO=X3/(sol_prk(1,j) + cbn_sp(j)%peroc_DOC*(surfq(j)+flat(1,j))) !CS is the horizontal concentration
              CS=cbn_sp(j)%peroc_DOC*CO                                     !CO is the vertical concentration
              VBC=CO*(sol_prk(1,j)) !!!    sol_prk(:,:) |mm H2O        |percolation from soil layer on current day
              sol_BMC(1,j)=sol_BMC(1,j)-X3
              QBC=CS*(surfq(j)+flat(1,j))
        !     COMPUTE WBMC LOSS WITH SEDIMENT
              IF(YEW>0.)THEN
                  CS=DK*sol_BMC(1,j)/XX
                  YBC=YEW*CS
              END IF
    !--------added by Du, update DOC mass and calculte DOC concentration in soil water---------------------------------
          DOC_mass=max(DOC_mass-X3,0.)          ! update DOC mass after leaching
          cbn_hru(j)%cbn_ly(1)%DOC=DOC_mass/(X2+1.E-10)*100 ! DOC contration in soil water (kg/ha to mg/L)
    !------------------------------------------------------------------------------------------------------------------
          END IF
      else
          cbn_hru(j)%cbn_ly(1)%DOC=0. ! added by Du, DOC contration in soil water
      END IF  !!IF(sol_BMC(1,j)>.00) THEN 

      sol_BMC(1,j)=sol_BMC(1,j)-YBC       
      cbn_hru(j)%trans%surfq_DOC=QBC*(surfq(j)/(surfq(j)+flat(1,j)+1.e-6)) ! added by Du, RDOC transported by surface runoff from top soil layer
      cbn_hru(j)%cbn_ly(1)%latly_DOC=QBC*(flat(1,j)/(surfq(j)+flat(1,j)+1.e-6))!added by Du, RDOC transported by latral flow from top soil layer
      cbn_hru(j)%cbn_ly(1)%percly_DOC=VBC                ! added by Du, RDOC perclation into second layer from top soil layer
      cbn_hru(j)%trans%latq_DOC=cbn_hru(j)%trans%latq_DOC+cbn_hru(j)%cbn_ly(1)%latly_DOC  ! added by Du,RDOC transported by latral flow of the whole soil profile 
      sedc_d(j) = YOC + YBC
      perc_clyr =0.
      perc_clyr = perc_clyr + cbn_hru(j)%cbn_ly(1)%percly_DOC ! DOC percolation of the whole soil profile
      !
      DO k=2,sol_nly(j)
          if (sol_prk(k,j) > 0 .and. k == sol_nly(j)) then
            !write (*,*) 'stop'
          end if
          sol_thick = 0.
          sol_thick = sol_z(k,j)-sol_z(k-1,j)
          sol_WOC(k,j) = sol_LSC(k,j)+sol_LMC(k,j)+sol_HPC(k,j)+sol_HSC(k,j) 
          Y1=sol_BMC(k,j)+VBC       ! added DOC percolation from upper layer
    !------------------------------------------------------------------------------------------------------------------------------------------------------------------
          ABL=1.-EXP(sol_st(k,j)+sol_wpmm(k,j)+.0001*cbn_sp(j)%kd_OC*sol_WOC(k,j))   !added by Du, carbon allocation coefficient ABL from biomass to leaching DOC
          DOC_mass=0.
          DOC_mass=ABL*sol_BMC(k,j)+VBC ! DOC mass in underlying soil layers (kg/ha) 
    !-------------------------------------------------------------------------------------------------------------------------------------------------------------------
          VBC=0.
          VBC1=0.  ! added by Du
          IF(Y1>=.01)THEN
              V=sol_prk(k,j) + flat(k,j)
              IF(V>0.)VBC1=Y1*(1.-EXP(-V/(sol_por(k,j)*sol_thick-sol_wpmm(k,j)+.0001*cbn_sp(j)%kd_OC*sol_WOC(k,j)))) ! VBC to VBC1             
          END IF
    !--------added by Du, update DOC mass and calculte DOC concentration in soil water-----------------------------------------------------!
          DOC_mass=max(DOC_mass-VBC1,0.)          ! update DOC mass after loss by leaching and lateral flow
          cbn_hru(j)%cbn_ly(k)%DOC=DOC_mass/(sol_st(k,j)+sol_wpmm(k,j)+1.E-10)*100 ! DOC contration in soil water (kg/ha to mg/L)
    !--------------------------------------------------------------------------------------------------------------------------------------!
          cbn_hru(j)%cbn_ly(k)%latly_DOC=VBC1*(flat(k,j)/(sol_prk(k,j) + flat(k,j)+1.e-6))! added by Du, leaching to underlying layer
          cbn_hru(j)%cbn_ly(k)%percly_DOC=VBC1-cbn_hru(j)%cbn_ly(k)%latly_DOC       ! added by Du, loss by lateral flow
          sol_BMC(k,j)=Y1-VBC1
          VBC=cbn_hru(j)%cbn_ly(k)%percly_DOC  ! added by Du, DOC percolation to the underlying soil layer    
          cbn_hru(j)%trans%latq_DOC=cbn_hru(j)%trans%latq_DOC+cbn_hru(j)%cbn_ly(k)%latly_DOC ! added by Du,RDOC transported by latral flow of the whole soil profile
        !! calculate nitrate in percolate        
        !perc_clyr = 0.
        perc_clyr = perc_clyr + cbn_hru(j)%cbn_ly(k)%percly_DOC  ! DOC percolation of the whole soil profile
    !------------------------added by Du, DIC processes in underlying layers------------------------------------------------------------------------!
        DIC_ly=0.
        DIC_ly=cbn_hru(j)%cbn_ly(k)%DIC+cbn_hru(j)%cbn_ly(k-1)%percly_DIC+sol_RSPC(k,j) !add DIC percolation from upper layer and OC minelization
        cbn_hru(j)%cbn_ly(k)%percly_DIC=0.
        if (DIC_ly>=0.)  then
            V=sol_prk(k,j) + flat(k,j)
            cw_DIC=0.
            if(V>0.) cw_DIC=DIC_ly*(1.-exp(-V/(sol_por(k,j)*sol_z(k,j))))/V ! DIC concentration in mobile water (kg/ha*mm)
            cbn_hru(j)%cbn_ly(k)%latly_DIC=cw_DIC*flat(k,j)
            cbn_hru(j)%trans%latq_DIC=cbn_hru(j)%trans%latq_DIC+cw_DIC*flat(k,j) !DIC loss by lateral flow of whole profile 
            cbn_hru(j)%cbn_ly(k)%percly_DIC=cw_DIC*sol_prk(k,j) ! DIC percolation into underlying layer
            cbn_hru(j)%cbn_ly(k)%DIC=DIC_ly-cw_DIC*V  ! update DIC mass by subtracting the transport loss 
            if (cbn_hru(j)%cbn_ly(k)%DIC <0.) cbn_hru(j)%cbn_ly(k)%DIC=0.       
        endif
    !------------------------added by Du, DIC processes in underlying layers------------------------------------------------------------------------!
      END DO
     
        percc_d(j) = perc_clyr
     !------------------------------added by Du, for carbon module------------------------------------------------------------------------------!
       cbn_hru(j)%perco_DOC=cbn_hru(j)%cbn_ly(sol_nly(j))%percly_DOC !Calculate DOC percolation amount from lowest soil layer to shallow aquifer
       !call gw_doc       !calculatig DOC processes in shallow aquifer
       cbn_hru(j)%trans%gwq_DOC =0.01* gw_q(j)*gwdoc_con(j)  !calculating DOC load using mean concentration (kg/ha)
       cbn_hru(j)%trans%LDOC=0.  !!no LDOC from HRU or landscape
     !------------------------------added by Du, for carbon module------------------------------------------------------------------------------!
      return
      end