subroutine carbon_cal
!This subroutine is for faciliting model calibration for organic carbon by reading parameter or 'borrowing' other SWAT paramters
use carbon_para
use parm

 integer :: option
 real :: kd_OC, perco_DOC,hlife_gw,klrd,kld,krd  !! for reading DOC parameters 
 real :: enr_POC,sv_lp,sv_rp,klp,kd_lp,klrp,krp,kd_rp
 character (len=80) ::  titldum
 
 option=2 ! calibration option: 1, reading parameter from input file 2, 'borrowing' other SWAT parameters for using SWAT-CUP
 
 if (option==1) then
      open (99999,file="carbon_para.txt")
      read (99999,*)  titldum
      read (99999,*)  kd_OC
      read (99999,*)  perco_DOC
      read (99999,*)  hlife_gw
      read (99999,*)  klrd
      read (99999,*)  kld
      read (99999,*)  krd
      read (99999,*)  enr_POC
      read (99999,*)  sv_lp
      read (99999,*)  sv_rp
      read (99999,*) klp
      read (99999,*) kd_lp
      read (99999,*) klrp
      read (99999,*) krp
      read (99999,*) kd_rp
      close (99999) 
      !
      cbn_sp%kd_OC= kd_OC
      cbn_sp%peroc_DOC=perco_DOC         ! 0-1
      cbn_sp%hlife_docgw=hlife_gw     ! 0-100       
      cbn_rp%klrd=klrd
      cbn_rp%kld=kld
      cbn_rp%krd=krd
    !in-stream DON parameters 
      kdon=0.018     !DON mineralization rate 0.0025-0.025  /day
      kpon=0.05      !PON hydrolysis rate 0.001-0.08   /day
      pon_set=0.5    !PON settling velocity 0-2.0 m/day
      !
      cbn_sp%enr_POC=enr_POC
      cbn_rp%sv_rp=sv_rp  ! 0-72 
      cbn_rp%sv_lp=sv_lp  ! 0-72 
      cbn_rp%klp=klp
      cbn_rp%kd_lp=kd_lp
      cbn_rp%klrp=klrp
      cbn_rp%krp=krp
      cbn_rp%kd_rp=kd_rp
 else
       !landscape transport parameters 
       cbn_sp%peroc_DOC=percop           ! 0-1
       cbn_sp%enr_POC=thbact             ! 0-10
       !cbn_sp%hlife_docgw=gdrain_bsn     ! 0-100        GDRAIN_BSN
       gwdoc_con=gdrain_bsn
       cbn_sp%kd_OC=ddrain_bsn            ! 0-2000
       !in-stream parameters
       kdon=wdlpq     !DON mineralization rate 0.0025-0.025  /day
       kpon=wglpq     !PON hydrolysis rate 0.001-0.08   /day
       pon_set=tdrain_bsn
       !cbn_rp%sv_rp=tdrain_bsn  ! 0-72 
       !cbn_rp%sv_lp=tdrain_bsn  ! 0-72 
       !cbn_rp%kld=wdlpq         !LDOC to DIC
       !cbn_rp%krd=wglpq         !RDOC to DIC
      !cbn_rp%kd_rp=wdps
      !cbn_rp%kd_lp=wgps
       !cbn_rp%klrp=wdlps
       !cbn_rp%klrd=wglps        !LDOC to RDOC
        !
        !restore the borrowed parameters to default values
         percop=0.5
         gdrain_bsn=0.0
         ddrain_bsn=0.0
         tdrain_bsn=0.0
         wdlpq=0.0
         wglpq=0.0
         !wglps=0.0
         thbact=1.07
         !

endif

return
end subroutine